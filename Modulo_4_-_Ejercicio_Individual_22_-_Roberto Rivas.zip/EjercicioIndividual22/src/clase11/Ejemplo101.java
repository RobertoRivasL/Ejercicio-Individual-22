package clase11;

public class Ejemplo101 {

    public static void main(String[] args) {

        int algo = 5;
        String var1 = "En un lugar de la Mancha, de cuyo \n" +
                "nombre no quiero acordarme, no ha mucho tiempo que vivía un \n" +
                "hidalgo de los de lanza en astillero, adarga antigua, rocín flaco y galgo corredor.\n " +
                "Una olla de algo más vaca que carnero \n" +
                "salpicón las más noches, duelos y quebrantos los sábados \n" +
                "lantejas los viernes, algún palomino de añadidura los domingos,\n" +
                "consumían las tres partes de su hacienda.";


        /*El resto della concluían sayo de velarte, calzas de
        velludo para las fiestas, con sus pantuflos de lo mesmo,
        y los días de entresemana se honraba con su
        vellorí de lo más fino*/


        int otraCosa = 6;

        System.out.println("El valor de la primera variable es: "+algo + " y de la segunda es: "+ otraCosa);
        System.out.println("¿Te cuento un cuento?:\n " + var1);


    }

}
